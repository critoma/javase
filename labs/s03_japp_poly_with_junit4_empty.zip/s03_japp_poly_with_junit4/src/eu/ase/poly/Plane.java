package eu.ase.poly;

//Create the Plane class which is inheriting Vehicle and it is adding the following private fields:
//- capacity: float
//- enginesNo: int
//- Create default constructor and constructor with parameters - using super
//- create get/set methods with eventual throw Exception statement
//- overwrite display method from Vehicle class
public class Plane {
	
}
