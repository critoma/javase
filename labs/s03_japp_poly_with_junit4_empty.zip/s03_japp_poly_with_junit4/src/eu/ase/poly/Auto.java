package eu.ase.poly;

// Create the Auto class which is inheriting Vehicle and it is adding the following private fields:
// - doorsNo: int
// - noCars: int static
// - Create default constructor and constructor with parameters
// - create get/set methods with eventual throw Exception statement
// - overwrite display method from Vehicle class and close (AutoCloseable interface) and clone (Cloneable interface) methods
public class Auto {
	
}
