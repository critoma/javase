package eu.ase.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

// create Invoice class which contains:
// A. Fields:
// A.1 - prices: double[]
// A.2 - units: int[]
// A.3 - descs: String[] - descriptions of the products within invoice
// B. Methods:
// B.1 - constructor: public Invoice(int[] units, double[] prices, String[] productsDesc)
// B.2 - get and set methods
// B.3 - public void saveInvoice2File(String invoiceFileName) - save the invoice values (in order of the described fields) 
// into a file
// B.4 - public double readInvoiceFromFileAndCalcTotal(String invoiceFileName) - read from the file and calculate 
// the total of the invoice
// B.5 - clone method for deep copy

public class Invoice implements Cloneable {
	
}
