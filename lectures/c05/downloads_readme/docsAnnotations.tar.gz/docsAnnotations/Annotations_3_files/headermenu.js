 function showMenuit(f){
 if(f){visi="visible";}
 else{visi="hidden";}
 if(document.layers){document.menuit.visibility=visi;}
 if(document.all){document.all.menuit.style.visibility=visi;}
 if(document.getElementById){document.getElementById("menuit").style.visibility=visi;}
 } 
 
 function showMenunc(f){
 if(f){visi="visible";}
 else{visi="hidden";}
 if(document.layers){document.menunc.visibility=visi;}
 if(document.all){document.all.menunc.style.visibility=visi;}
 if(document.getElementById){document.getElementById("menunc").style.visibility=visi;}
 } 
 
 function showMenuweb(f){
 if(f){visi="visible";}
 else{visi="hidden";}
 if(document.layers){document.menuweb.visibility=visi;}
 if(document.all){document.all.menuweb.style.visibility=visi;}
 if(document.getElementById){document.getElementById("menuweb").style.visibility=visi;}
 } 
 
 function showMenuhw(f){
 if(f){visi="visible";}
 else{visi="hidden";}
 if(document.layers){document.menuhw.visibility=visi;}
 if(document.all){document.all.menuhw.style.visibility=visi;}
 if(document.getElementById){document.getElementById("menuhw").style.visibility=visi;}
 } 
 
 function showMenusw(f){
 if(f){visi="visible";}
 else{visi="hidden";}
 if(document.layers){document.menusw.visibility=visi;}
 if(document.all){document.all.menusw.style.visibility=visi;}
 if(document.getElementById){document.getElementById("menusw").style.visibility=visi;}
 } 
 
 function showMenuitnews(f){
 if(f){visi="visible";}
 else{visi="hidden";}
 if(document.layers){document.menuitnews.visibility=visi;}
 if(document.all){document.all.menuitnews.style.visibility=visi;}
 if(document.getElementById){document.getElementById("menuitnews").style.visibility=visi;}
 } 
