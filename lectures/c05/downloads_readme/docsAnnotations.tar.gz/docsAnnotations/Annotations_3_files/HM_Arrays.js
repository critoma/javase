/*,HM_Array1 = [
[,      // menu width
"HM_GetElementLeft(window.theEvent)", //left_position
102,			//top_position
],
["Core US Analyst Research","http://www.jmm.com/xp/jmm/services/jup/analystResearch.xml",1,0,0],
["Core European Analyst Research","http://www.jmm.com/xp/jmm/services/jup/europeanAnalystResearch.xml",1,0,0],
["Industry Essentials","http://www.jmm.com/xp/jmm/services/jup/industryEssentials.xml",1,0,0],
["Custom Research","http://www.jmm.com/xp/jmm/services/jup/customResearch.xml",1,0,0]
["Research Deliverables","http://www.jmm.com/xp/jmm/services/jup/researchDeliverables.xml",1,0,0]
["Advisor Program","http://www.jmm.com/xp/jmm/services/jup/advisorProgram.xml",1,0,0]
]*/

HM_Array1 = [
[,      // menu width
170, //left_position
276,			//top_position
],
["EJB/Components","http://www.developer.com/java/ejb",1,0,0],
["Enterprise Java","http://www.developer.com/java/ent",1,0,0],
["J2ME","http://www.developer.com/java/j2me",1,0,0],
["Data & Java","http://www.developer.com/java/data",1,0,0],
["Web-based Java","http://www.developer.com/java/web",1,0,0],
["Other Java","http://www.developer.com/java/other",1,0,0]
]



HM_Array2 = [
[,      // menu width
170, //left_position
297,			//top_position
],
["CGI","http://www.developer.com/lang/cgi",1,0,0],
["CSS","http://www.developer.com/lang/css",1,0,0],
["DHTML","http://www.developer.com/lang/dhtml",1,0,0],
["JavaScript / Jscript","http://www.developer.com/lang/jscript",1,0,0],
["Perl","http://www.developer.com/lang/perl",1,0,0],
["PHP","http://www.developer.com/lang/php",1,0,0],
["Other","http://www.developer.com/lang/other",1,0,0]
]

HM_Array3 = [
[,      // menu width
170, //left_position
318,			//top_position
],
[".NET","http://www.developer.com/net/net",1,0,0],
["ASP & ASP.NET","http://www.developer.com/net/asp",1,0,0],
["Visual Basic","http://www.developer.com/net/vb",1,0,0],
["Visual C#","http://www.developer.com/net/csharp",1,0,0],
["Visual C++","http://www.developer.com/net/cplus",1,0,0]
]



HM_Array4 = [
[,      // menu width
170, //left_position
431,			//top_position
],
["BREW","http://www.developer.com/ws/brew",1,0,0],
["J2ME","http://www.developer.com/ws/j2me",1,0,0],
["Palm","http://www.developer.com/ws/palm",1,0,0],
["Pocket PC/WinCE","http://www.developer.com/ws/pc",1,0,0],
["Protocols/Standards","http://www.developer.com/ws/proto",1,0,0],
["Other Wireless/Mobile","http://www.developer.com/ws/other",1,0,0]
]
