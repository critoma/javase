function motifWriteHtml(html) {
	document.write(html);
}