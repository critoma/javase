function DocumentDotWrite(s){document.write(s);}
