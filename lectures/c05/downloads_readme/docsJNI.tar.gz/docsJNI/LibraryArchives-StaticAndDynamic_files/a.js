	
	var jobthread_widget_title;
	var jobthread_widget_outer_style;
	var jobthread_widget_inner_style;
	var jobthread_widget_title_style;
	var jobthread_widget_link_style;
	var jobthread_widget_top_style;
	var jobthread_widget_bottom_style;

	if (!jobthread_widget_title) {
		jobthread_widget_title = "Jobs";
	}
	if (!jobthread_widget_outer_style) {
		jobthread_widget_outer_style = "background-color:#dddddd;border:1px solid #999999;width:160px;";
	}
	if (!jobthread_widget_inner_style) {
		jobthread_widget_inner_style = "background-color:#ffffff;color:#666666;border:1px solid #999999;padding:10px 10px 2px 8px;font:11px Arial, Helvetica, Sans-serif;line-height:16px;";
	}
	if (!jobthread_widget_title_style) {
		jobthread_widget_title_style = "color:#313131;font-weight:bold;";
	}
	if (!jobthread_widget_link_style) {
		jobthread_widget_link_style = "color:#0464bb;font-size:11px;font-weight:normal;text-decoration:none;border:none;";
	}
	if (!jobthread_widget_top_style) {
		jobthread_widget_top_style = "padding-top:8px;";
	}
	if (!jobthread_widget_bottom_style) {
		jobthread_widget_bottom_style = "padding-bottom:4px;";
	}
	

	document.write('<div style="' + jobthread_widget_outer_style + '"><div style="' + jobthread_widget_top_style + '"><div style="margin-left:10px;margin-bottom:8px;' + jobthread_widget_title_style + '">' + jobthread_widget_title + '</div></div><div style="' + jobthread_widget_inner_style + '"><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2357271" style="' + jobthread_widget_link_style + '" target="_top">Game Developer - Innovative Developer</a><br />United Kingdom<br />Interactive Selection</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2442692" style="' + jobthread_widget_link_style + '" target="_top">SAP ABAP Junior Developer</a><br />Basel, Basel-Stadt, Switzerland<br />Recolade Limited</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2423997" style="' + jobthread_widget_link_style + '" target="_top">VFX Programmer - Racing Titles</a><br />United Kingdom<br />Interactive Selection</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2437724" style="' + jobthread_widget_link_style + '" target="_top">Application Developer</a><br />Salisbury, Wiltshire, United Kingdom<br />Hays - South Coast</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2425366" style="' + jobthread_widget_link_style + '" target="_top">.NET Software Engineer</a><br />boston, MA<br />Makro Technologies</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2461231" style="' + jobthread_widget_link_style + '" target="_top">SENIOR SOFTWARE ENGINEER (FLASH/HTML 5)</a><br />Atlanta, GA<br />Synergy Network Solutions, Inc</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2444565" style="' + jobthread_widget_link_style + '" target="_top">Software Architect / Senior...</a><br />Frankfurt am Main, Hessen, Germany<br />Prodyna AG</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2307875" style="' + jobthread_widget_link_style + '" target="_top">Software Engineer-AAA Games</a><br />Sweden<br />Interactive Selection</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2433954" style="' + jobthread_widget_link_style + '" target="_top">Jr Windows Desktop Support Engineer...</a><br />New York, NY<br />undisclosed</div><div style="margin-bottom:5px;"><a href="http://www.jobthread.com/jt/jobs/widget_click.php?id=c0e4b3&job_id=2423831" style="' + jobthread_widget_link_style + '" target="_top">Softwareentwickler (m/w) Java</a><br />Mitte, Berlin, Germany<br />optivo GmbH</div><div style="margin-top:10px;margin-bottom:5px;"><a href="http://www.jobthread.com/" style="text-transform:uppercase;' + jobthread_widget_link_style + '">Post a Job &gt;</a></div></div><div style="' + jobthread_widget_bottom_style + ';text-align:center;margin-top:8px;cursor:pointer;display:block;visibility:visible;" onclick="window.location=\'http://www.jobthread.com/\';"><div style="text-transform:uppercase;font-family:Arial,Helvetica;font-size:9px;cursor:pointer;">Powered by JobThread</div><img src="http://static.jobthread.com/partners/jobthread/images/logo_small.gif" style="margin-top:4px;margin-bottom:4px;margin-left:auto;margin-right:auto;border:none;" /></a></div></div>');



	
	
	var _qevents = _qevents || [];

	(function() {
	var elem = document.createElement('script');
	elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") + ".quantserve.com/quant.js";
	elem.async = true;
	elem.type = "text/javascript";
	var scpt = document.getElementsByTagName('script')[0];
	scpt.parentNode.insertBefore(elem, scpt);
	})();

	_qevents.push({
		qacct: "p-dfaywUr_Oq7jw",
		labels: ""
	});
	
