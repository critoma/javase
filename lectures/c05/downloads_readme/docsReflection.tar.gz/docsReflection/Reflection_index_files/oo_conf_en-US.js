/* OnlineOpinion (F3cS,en-US) */
/* This product and other products of OpinionLab, Inc. are protected by U.S. Patent No. 6606581, 6421724, 6785717 B1 and other patents pending. */
custom_var ='xx';
function O_SunPos() {
	if((typeof _b=='undefined'?0:_b.clientWidth>=875)||(_w.innerWidth>=875)){_sticky=1;_sticky_x=905-(_d.all?15:0)+((typeof _b=='undefined'?_w.innerWidth:_b.clientWidth)-875)/2;_sticky_y=-1};
	O_Rz()
}_w.onresize=O_SunPos;O_SunPos();

var O_pth='/js/op/',O_color='black',O_tmoff=3600000;_aLg=new Array("en-US","","Please click here to give us feedback.","Comments?", "0");O_lang=_aLg[4];O_pth+=_aLg[0]+'/';O_pth+=O_color;
_top=0;_fb=1;O_GoC('<table cellspacing="0" cellpadding="0" border="0"><tr><td align="center" style="text-align:center"><a href="#" onMouseOver="_stop=0" onMouseOut="_stop=1;_Sh(\'O_c\',0);_Sh(\'O_o\',1);return 1"><img src="'+O_pth+'_oo.gif" border="0" width="19" height="17" alt="'+_aLg[1]+'" title="'+_aLg[1]+'"></a></td></tr><tr><td align="center" style="text-align:center"><a href="#" onMouseOver="_stop=1" onMouseOut="_stop=1;_Sh(\'O_c\',0);_Sh(\'O_o\',1);return 1"><img src="'+O_pth+'_fb_'+_aLg[0]+'.gif" border="0"></a></td></tr></table></div><br><div id="O_c" style="position:absolute;top:0px;left:0px;visibility:hidden;z-index:999"><table cellpadding="0" cellspacing="0" border="0" valign="top" align="left" width="138"><tr><td>'+_alk+'<img src="'+O_pth+'_popns_'+_aLg[0]+'.gif" alt="'+_aLg[2]+'" title="'+_aLg[2]+'" border="0" width="115" height="56"></a>'+_alk+'<img src="'+O_pth+'_dot.gif" alt="" title="" width="4" height="17" border="0"><img src="'+O_pth+'_comment.gif" alt="'+_aLg[3]+'" title="'+_aLg[3]+'" border="0" width="19" height="17"></a>');
