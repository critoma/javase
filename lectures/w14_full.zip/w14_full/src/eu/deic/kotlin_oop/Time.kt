package eu.deic.kotlin_oop

class MyTime {

    private val hours: Int
    private val minutes: Int
    private val seconds: Int

    constructor() {
        this.hours = 0
        this.minutes = 0
        this.seconds = 0
    }

    constructor(hours: Int, minutes: Int, seconds: Int) {
        this.hours = hours
        this.minutes = minutes
        this.seconds = seconds
    }

    constructor(hours: Int, minutes: Int, seconds: Int, nanoSec: Int) {
        this.hours = hours
        this.minutes = minutes
        this.seconds = seconds
    }

    constructor(serializedString: String) {
        val subs = serializedString.split(":")
        this.hours = subs[0].toInt()
        this.minutes = subs[1].toInt()
        this.seconds = subs[2].toInt()
    }

    fun serialize(): String {
        return "{%02d}:{%02d}:{%02d}".format(hours, minutes, seconds)
    }

    public fun getHours(): Int {
        return this.hours
    }

    public fun getMinutes(): Int {
        return this.minutes
    }

    public fun getSeconds(): Int {
        return this.seconds
    }
}

fun main(args: Array<String>) {

    var t1 = MyTime("2:22:38")
    println("\n t1 = " + t1.serialize())

    var t2 = MyTime(2, 39, 45, 28)
    println("\n t2 = " + t2.serialize())

    var t3 = MyTime()
    println("\n t3 = " + t3.serialize())

    var t4: MyTime?
    // after 200 line of code
    if (t2.getHours() == 2) {
        t4 = null
    } else {
        t4 = MyTime()
    }
    //if (t4 != null) //not necessary
    println(t4?.serialize())

}