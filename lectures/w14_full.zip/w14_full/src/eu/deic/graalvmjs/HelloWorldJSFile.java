package eu.deic.graalvmjs;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;

// https://golb.hplar.ch/2020/04/java-javascript-engine.html
// https://mvnrepository.com/artifact/org.graalvm.js/js/22.0.0.2
// view all: https://repo1.maven.org/maven2/org/graalvm/js/js/22.0.0.2/
// https://github.com/ralscha/blog2020/blob/master/jsengine/pom.xml#L15-L24

// mvn dependency:copy-dependencies -DoutputDirectory="c:\temp"

// export MVN_HOME=/opt/software/apache-maven-3.5.0
// ctoma@Cristians-MacBook-Pro-2015 lib % export PATH=.:$MVN_HOME/bin:$PATH
// ctoma@Cristians-MacBook-Pro-2015 lib % pwd
// /Users/ctoma/eclipse-workspace-jee2022/japp_j2js/lib
// mvn dependency:copy-dependencies -DoutputDirectory="."

// For more information on using GraalVM see https://www.graalvm.org/java/quickstart/.
// To disable this warning the '--engine.WarnInterpreterOnly=false' option or use the '-Dpolyglot.engine.WarnInterpreterOnly=false' system property.

public class HelloWorldJSFile {

    public static void main(String[] args) throws Exception {
        ScriptEngineManager sEngMng = new ScriptEngineManager();

        // Sets up Nashorn or GraalVM JavaScript Engine
        ScriptEngine sEngine = sEngMng.getEngineByExtension("js"); // sEngine.getEngineByName("graal.js"); //getEngineByName("nashorn");

        // Nashorn JavaScript syntax.
        sEngine.eval("print ('Hello, ')");

        String name = "Hello name ";
        Integer result = null;

        try {
            sEngine.eval("print('" + name + "')");
            result = (Integer) sEngine.eval("10 + 2");
        } catch(ScriptException e) {
            System.out.println("Error executing script: "+ e.getMessage());
        }

        System.out.println(result.toString());

        // hworld.js contents: print('World!\n');
        Path p1 = Paths.get("./src/eu/deic/graalvmjs/hworld.js");
        sEngine.eval(new FileReader(p1.toString()));

        Path p2 = Paths.get("./src/eu/deic/graalvmjs/pcallback.js");
        sEngine.eval(new FileReader(p2.toString()));
    }

}
