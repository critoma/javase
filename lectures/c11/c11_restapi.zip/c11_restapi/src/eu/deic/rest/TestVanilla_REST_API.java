package eu.deic.rest;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.Headers;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;

// https://happycoding.io/tutorials/java-server/rest-api
// https://www.educative.io/answers/how-to-make-a-rest-api-in-java

public class TestVanilla_REST_API {

	public static void main(String[] args) {
		try {
			System.out.printf("%s", "DEIC/DICE 'Naive' REST API Server started!");
			HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

			// curl -X GET http://127.0.0.1:8080/api/greeting
			server.createContext("/api/greeting", (exchange -> {

				if ("GET".equals(exchange.getRequestMethod())) {
					String responseText = "{'message':'Hello World! from our 'framework-less' REST API'}\n";
					exchange.sendResponseHeaders(200, responseText.getBytes().length);
					OutputStream output = exchange.getResponseBody();
					output.write(responseText.getBytes());
					output.flush();
				} else {
					exchange.sendResponseHeaders(405, -1);// 405 Method Not Allowed
				}
				exchange.close();
			}));

			// curl -d '{"key1":"value1", "key2":"value2"}' -H "Content-Type: application/json" -X POST http://127.0.0.1:8080/api/testPOST
			server.createContext("/api/testPOST", new MyPOSTHandler());

			server.setExecutor(null); // creates a default executor
			server.start();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	} // end main

} // end class Test API

class MyPOSTHandler implements HttpHandler {
	@Override
	public void handle(HttpExchange he) throws IOException {
		System.out.println("Serving the POST request");

		if (he.getRequestMethod().equalsIgnoreCase("POST")) {
			try {
				Headers requestHeaders = he.getRequestHeaders();
				Set<Map.Entry<String, List<String>>> entries = requestHeaders.entrySet();

				int contentLength = Integer.parseInt(requestHeaders.getFirst("Content-length"));
				System.out.println("" + requestHeaders.getFirst("Content-length"));

				InputStream is = he.getRequestBody();

				byte[] data = new byte[contentLength];
				int length = is.read(data);

				Headers responseHeaders = he.getResponseHeaders();
				System.out.println(responseHeaders);

				he.sendResponseHeaders(HttpURLConnection.HTTP_OK, contentLength);

				OutputStream os = he.getResponseBody();

				os.write(data);
				System.out.printf("req headers = %s, read length = %d, data = %s \n", entries.toString(), length, new String(data, StandardCharsets.UTF_8));
				he.close();

			} catch (NumberFormatException | IOException e) {
			}
		}

	}
}
