package net.searchdaily.java.design.pattern.factorymethod;

/**
 * Factory Method pattern tutorial by searchdaily.net
 * 
 * @author namnvhue
 * 
 */
public class CalculatorSelector {
	public static void main(String[] args) {
		CalculatorFactory factory = new CalculatorFactory();
		Calculator calculator1 = factory.getCalculator("P", "a Programmer Calculator");
		Calculator c2 = factory.getCalculator("B", "a Basic Calculator");
		System.out.println("c1 type: " + calculator1.getClass().getName());
		System.out.println("c2 type: " + c2.getClass().getName());
	}
}
