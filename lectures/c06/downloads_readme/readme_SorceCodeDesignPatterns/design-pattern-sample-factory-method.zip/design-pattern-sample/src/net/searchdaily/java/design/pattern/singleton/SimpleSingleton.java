package net.searchdaily.java.design.pattern.singleton;
/**
 * This class is to demo simple Singleton pattern.
 * @author namnvhue
 * bring to you by http://java.searchdaily.net. *
 */
public class SimpleSingleton {
	private static SimpleSingleton singletonInstance = null;
	//Mark the constructor private to avoid object creation outside.
	private SimpleSingleton() {
		
	}
	//This is where other object can obtain instance of this class.
	public static SimpleSingleton getInstance() {
		if (null == singletonInstance) {
			singletonInstance = new SimpleSingleton();
		}
		
		return singletonInstance;
	}
}
