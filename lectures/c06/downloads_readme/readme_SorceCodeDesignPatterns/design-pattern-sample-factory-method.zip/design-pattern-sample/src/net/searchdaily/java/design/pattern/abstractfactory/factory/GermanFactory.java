package net.searchdaily.java.design.pattern.abstractfactory.factory;

import net.searchdaily.java.design.pattern.abstractfactory.product.Audi;
import net.searchdaily.java.design.pattern.abstractfactory.product.CarSpec;
import net.searchdaily.java.design.pattern.abstractfactory.product.MercedesBenzTruck;
import net.searchdaily.java.design.pattern.abstractfactory.product.TruckSpec;

/**
 * This is the Concrete Vehicle Factory based in Germany. Where Mercedes-Benz
 * truck and Audi car are made. Abstract Factory tutorial brought to you by
 * http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public class GermanFactory extends VehicleFactory {

	@Override
	public CarSpec getCar() {
		return new Audi("Audi A8");
	}

	@Override
	public TruckSpec getTruck() {
		return new MercedesBenzTruck("Mercedes-Benz Axor",
				"mid-sized truck from 18 to 26 tonnes in rigid and articulated");
	}

}
