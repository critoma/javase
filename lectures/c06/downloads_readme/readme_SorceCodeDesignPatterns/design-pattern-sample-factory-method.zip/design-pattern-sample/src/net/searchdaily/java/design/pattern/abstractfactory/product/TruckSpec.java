package net.searchdaily.java.design.pattern.abstractfactory.product;

/**
 * This interface is for describing the "truck product". Abstract factory tutorial
 * brought to you by http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public interface TruckSpec {
	public String getTruckName(); //to get the truck name

	public String getTruckEngine(); //to get the truck engine name.

	public String getTruckLoads(); //to get the carry load.
}
