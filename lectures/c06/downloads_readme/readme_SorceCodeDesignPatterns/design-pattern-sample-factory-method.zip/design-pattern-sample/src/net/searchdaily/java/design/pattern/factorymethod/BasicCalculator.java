package net.searchdaily.java.design.pattern.factorymethod;

/**
 * Factory Method pattern tutorial by searchdaily.net
 * 
 * @author namnvhue
 * 
 */
public class BasicCalculator extends Calculator {
	public BasicCalculator(String name) {
		System.out.println("Hello I'm " + name);
	}
}
