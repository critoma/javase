package net.searchdaily.java.design.pattern.abstractfactory.product;

/**
 * This interface is for describing the "car product". Abstract factory tutorial
 * brought to you by http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public interface CarSpec {
	public String getCarName(); // use to get car name

	public double getMaxSpeed(); // use the get max speed of the car

	public String getCarFeatures(); // use to get more features.
}
