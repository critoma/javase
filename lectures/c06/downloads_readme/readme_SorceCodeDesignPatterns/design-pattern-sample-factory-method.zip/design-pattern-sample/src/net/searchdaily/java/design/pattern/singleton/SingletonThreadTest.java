package net.searchdaily.java.design.pattern.singleton;

/**
 * This class is to demo simple Singleton pattern.
 * @author namnvhue
 * bring to you by http://java.searchdaily.net. *
 */
public class SingletonThreadTest {
	public static void main(String[] args) {
		try {
			Thread thread1 = new Thread(new SingletonThreadRunner());
			Thread thread2 = new Thread(new SingletonThreadRunner());
			thread1.start();
			thread2.start();
			thread1.join();
			thread2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
