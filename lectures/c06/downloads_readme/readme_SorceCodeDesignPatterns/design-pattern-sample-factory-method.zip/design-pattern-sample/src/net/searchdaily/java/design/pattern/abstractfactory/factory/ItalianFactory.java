package net.searchdaily.java.design.pattern.abstractfactory.factory;

import net.searchdaily.java.design.pattern.abstractfactory.product.CarSpec;
import net.searchdaily.java.design.pattern.abstractfactory.product.Ferrari;
import net.searchdaily.java.design.pattern.abstractfactory.product.IvecoTruck;
import net.searchdaily.java.design.pattern.abstractfactory.product.TruckSpec;

/**
 * This is the Concrete Vehicle Factory based in Italy. Where Iveco truck and
 * Ferrari car are made Abstract Factory tutorial brought to you by
 * http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public class ItalianFactory extends VehicleFactory {

	@Override
	public CarSpec getCar() {
		return new Ferrari("Ferrari F430");
	}

	@Override
	public TruckSpec getTruck() {
		return new IvecoTruck("Iveco EuroCargo", "6.5 - 18 t GVW");
	}

}
