package net.searchdaily.java.design.pattern.factorymethod;

/**
 * Factory Method pattern tutorial by searchdaily.net
 * 
 * @author namnvhue
 * 
 */
public class CalculatorFactory {
	public Calculator getCalculator(final String type, final String name) {
		if ("B".equals(type)) {
			return new BasicCalculator(name);
		} else if ("S".equals(type)) {
			return new ScientificCalculator(name);
		} else if ("P".equals(type)) {
			return new ProgrammerCalculator(name);
		} else {
			return new Calculator();
		}
	}
}
