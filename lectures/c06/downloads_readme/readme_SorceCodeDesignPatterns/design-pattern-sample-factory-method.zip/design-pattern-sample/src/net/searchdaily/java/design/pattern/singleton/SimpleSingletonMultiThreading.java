package net.searchdaily.java.design.pattern.singleton;
/**
 * This class is to demo simple Singleton pattern.
 * @author namnvhue
 * bring to you by http://java.searchdaily.net. *
 */
public class SimpleSingletonMultiThreading {
	private static SimpleSingletonMultiThreading singletonInstance = null;
	private static boolean isFirstThread = true;

	// Mark the constructor private to avoid object creation outside.
	private SimpleSingletonMultiThreading() {

	}

	// This is where other object can obtain instance of this class.
	public static SimpleSingletonMultiThreading getInstance() {
		if (null == singletonInstance) {
			doSomethingIfFirstThread(); // just for easier to understand
			singletonInstance = new SimpleSingletonMultiThreading();
		}

		return singletonInstance;
	}

	@SuppressWarnings("static-access")
	public static void doSomethingIfFirstThread() {
		try {
			if (isFirstThread) {
				isFirstThread = false;
				// Make the current thread take a short nap.
				Thread.currentThread().sleep(50);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
