package net.searchdaily.java.design.pattern.abstractfactory.product;

/**
 * This interface is for describing the "Iveco truck product". Abstract factory
 * tutorial brought to you by http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public class IvecoTruck implements TruckSpec {
	private String name;
	private String load;

	public IvecoTruck(String name, String load) {
		this.name = name;
		this.load = load;
	}

	@Override
	public String getTruckName() {
		return this.name;
	}

	@Override
	public String getTruckEngine() {
		return "Volvo best engine";
	}

	@Override
	public String getTruckLoads() {
		return this.load;
	}
	
	@Override
	public String toString() {
		return "IvecoTruck: " + name + "," + getTruckLoads();
	}

}
