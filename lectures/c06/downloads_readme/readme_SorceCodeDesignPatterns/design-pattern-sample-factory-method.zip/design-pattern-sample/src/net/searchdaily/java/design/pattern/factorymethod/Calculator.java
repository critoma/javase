package net.searchdaily.java.design.pattern.factorymethod;

/**
 * Factory Method pattern tutorial by searchdaily.net
 * 
 * @author namnvhue
 * 
 */
public class Calculator {
	public Calculator() {

	}

	protected String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	protected String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
