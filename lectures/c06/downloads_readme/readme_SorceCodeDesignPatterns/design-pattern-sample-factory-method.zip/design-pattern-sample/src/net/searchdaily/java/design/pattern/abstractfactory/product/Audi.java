package net.searchdaily.java.design.pattern.abstractfactory.product;
/**
 * This interface is for describing the "Audi product". Abstract factory
 * tutorial brought to you by http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public class Audi implements CarSpec {
	private String name;
	
	public Audi(String name) {
		this.name = name;
	}
	
	@Override
	public String getCarName() {
		return this.name;
	}

	@Override
	public double getMaxSpeed() {
		return 350;
	}

	@Override
	public String getCarFeatures() {
		return "Audi is smarter and more prettier";
	}

	@Override
	public String toString() {
		return name + ", " + getMaxSpeed() +", " + getCarFeatures();
	}
}
