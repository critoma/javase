package net.searchdaily.java.design.pattern.abstractfactory.factory;

/**
 * This is the simple test to show how the Abstract Factory works. Try it
 * yourself and have fun :). Abstract Factory tutorial brought to you by
 * http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public class TestAbstractFactory {
	public static void main(String[] args) {
		VehicleFactory abstractFactory;
		abstractFactory = VehicleFactory.getFactory("german"); // obtain the
																// German
																// factory
		System.out.println("German Vehicle Factory products list: ");
		System.out.println(abstractFactory.getCar());
		System.out.println(abstractFactory.getTruck());

		System.out.println("-----------------------");
		abstractFactory = VehicleFactory.getFactory("italian"); // obtain the
																// Italian
																// factory
		System.out.println("Italian Vehicle Factory products list: ");
		System.out.println(abstractFactory.getCar());
		System.out.println(abstractFactory.getTruck());

	}
}
