package net.searchdaily.java.design.pattern.singleton;
/**
 * This class is to demo simple Singleton pattern.
 * @author namnvhue
 * bring to you by http://java.searchdaily.net. *
 */
public class SingletonThreadRunner implements Runnable {

	@Override
	public void run() {
		 // Get a reference to the singleton.
		SimpleSingletonMultiThreading singleton = 
				SimpleSingletonMultiThreading.getInstance();        
	}
}
