package net.searchdaily.java.design.pattern.abstractfactory.factory;

import net.searchdaily.java.design.pattern.abstractfactory.product.CarSpec;
import net.searchdaily.java.design.pattern.abstractfactory.product.TruckSpec;

/**
 * This is the Abstract Factory where it can return to you the concrete factory
 * for making a car or truck. Abstract Factory tutorial brought to you by
 * http://java.searchdaily.net. *
 * 
 * @author namnvhue
 * 
 */
public abstract class VehicleFactory {
	public static final String ITALIAN_PRODUCT = "italian"; 
	public static final String GERMAN_PRODUCT = "german";

	public abstract CarSpec getCar();

	public abstract TruckSpec getTruck();

	public static VehicleFactory getFactory(String factoryType) {
		if (ITALIAN_PRODUCT.equalsIgnoreCase(factoryType)) {
			return new ItalianFactory();
		} else if (GERMAN_PRODUCT.equalsIgnoreCase(factoryType)) {
			return new GermanFactory();
		} else { // the default case I choose to return a ItalianFactory
			return new ItalianFactory();
		}

	}
}
