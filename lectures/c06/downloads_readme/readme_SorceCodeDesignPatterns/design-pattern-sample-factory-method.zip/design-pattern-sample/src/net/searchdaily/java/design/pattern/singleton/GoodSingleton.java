package net.searchdaily.java.design.pattern.singleton;
/**
 * This class is to demo simple Singleton pattern.
 * @author namnvhue
 * bring to you by http://java.searchdaily.net. *
 */
public class GoodSingleton {
	private static GoodSingleton singletonInstance = null;
	//Mark the constructor private to avoid object creation outside.
	private GoodSingleton() {
		
	}
	//we mark the method synchronized so that concurrency won't beat it.
	public static synchronized GoodSingleton getInstance() {
		if (null == singletonInstance) {
			singletonInstance = new GoodSingleton();
		}
		
		return singletonInstance;
	}
}
