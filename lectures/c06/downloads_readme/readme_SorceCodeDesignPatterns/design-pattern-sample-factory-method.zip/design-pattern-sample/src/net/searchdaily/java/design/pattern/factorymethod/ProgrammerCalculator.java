package net.searchdaily.java.design.pattern.factorymethod;

/**
 * Factory Method pattern tutorial by searchdaily.net
 * 
 * @author namnvhue
 * 
 */
public class ProgrammerCalculator extends Calculator {
	public ProgrammerCalculator(String name) {
		System.out.println("Hello I'm " + name);
	}
}
