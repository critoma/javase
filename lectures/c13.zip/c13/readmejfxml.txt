https://openjfx.io/
https://gluonhq.com/products/javafx/
https://openjfx.io/openjfx-docs/

JVM Arguments:
--module-path "C:\Users\jcdev.SECBRO03\Downloads\javafx-sdk-11.0.2\lib" --add-modules javafx.controls,javafx.fxml